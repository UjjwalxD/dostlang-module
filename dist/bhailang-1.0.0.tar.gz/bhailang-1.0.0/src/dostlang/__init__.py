
class DostLang:
    def __init__(self, msg):
        self.msg = msg
        
    def bolbhai(msg):
        print(msg)
        
        
        