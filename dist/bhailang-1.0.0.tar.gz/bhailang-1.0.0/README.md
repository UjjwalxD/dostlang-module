# DostLang v1.0.0

This is a python module made for fun in coding.
[Home](https://github.com/UjjwalxD/dostlang-module/)


```bash
pip install dostlang
```
```bash
from dostlang import DostLang
```
```bash
bolbhai("hello...")
```